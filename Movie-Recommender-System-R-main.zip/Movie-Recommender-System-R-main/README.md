# Movie-Recommender-System
A movie recommender system based on Data Analytics which recommends users movies based on the movies they searched to find more similar ones.
